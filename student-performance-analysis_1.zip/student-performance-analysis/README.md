# Student Performance Analysis Dashboard

A deep-space themed interactive academic analytics dashboard.

## Live Demo
[Click here to open dashboard](https://YOUR-USERNAME.github.io/student-performance-analysis/)

## Features
- Animated particle background
- Live bar chart (Chart.js)
- Class average, highest & lowest score cards
- Auto status badges per student
- Fully responsive

## How to use
1. Enter student names and marks
2. Click Analyse
3. See results instantly

## Tech Stack
- HTML5 Canvas (animated background)
- Chart.js 4.4.1
- Pure Vanilla JavaScript
- Google Fonts (DM Sans + Space Mono)
