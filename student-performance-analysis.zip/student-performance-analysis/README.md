<div align="center">

# 📊 Student Performance Analysis Dashboard

### A deep-space themed interactive academic analytics dashboard

[![Live Demo](https://img.shields.io/badge/🚀%20Live%20Demo-Click%20to%20Open-6366f1?style=for-the-badge&logoColor=white)](https://YOUR-USERNAME.github.io/student-performance-analysis/)
[![HTML](https://img.shields.io/badge/HTML5-Pure%20Frontend-E34F26?style=for-the-badge&logo=html5&logoColor=white)](https://developer.mozilla.org/en-US/docs/Web/HTML)
[![Chart.js](https://img.shields.io/badge/Chart.js-4.4.1-FF6384?style=for-the-badge&logo=chart.js&logoColor=white)](https://www.chartjs.org/)
[![GitHub Pages](https://img.shields.io/badge/GitHub%20Pages-Deployed-222222?style=for-the-badge&logo=github&logoColor=white)](https://pages.github.com/)

---

![Student Performance Dashboard Preview](preview.png)

---

</div>

## 🌌 Overview

A fully interactive **Student Academic Performance Dashboard** built with pure HTML, CSS, and JavaScript — no frameworks, no backend required. Features a stunning animated deep-space background with floating particles, glowing orbs, and a frosted-glass UI.

---

## ✨ Features

| Feature | Description |
|---|---|
| 🎨 **Animated Background** | Live particle network with connecting lines and glowing orbs |
| 📊 **Live Bar Chart** | Chart.js powered performance visualization |
| 🏆 **Smart Metric Cards** | Class average, highest & lowest scores with student names |
| 🏷️ **Auto Badges** | Top Scorer / Average / Needs Improvement auto-assigned |
| 📱 **Responsive Design** | Works on desktop, tablet, and mobile |
| ⚡ **Zero Dependencies** | Single HTML file — open and run instantly |

---

## 🚀 Live Demo

> **[👉 Click here to open the dashboard](https://YOUR-USERNAME.github.io/student-performance-analysis/)**

No installation needed — the link opens the fully interactive dashboard directly in your browser.

---

## 📁 Project Structure

```
student-performance-analysis/
│
├── index.html               ← Main dashboard (single file app)
├── preview.png              ← Dashboard screenshot
├── README.md                ← This file
│
└── .github/
    └── workflows/
        └── deploy.yml       ← Auto GitHub Pages deployment
```

---

## 🛠️ How to Use

### Option 1 — Open Locally
```bash
# Clone the repo
git clone https://github.com/YOUR-USERNAME/student-performance-analysis.git

# Open in browser
open index.html
```

### Option 2 — Live via GitHub Pages
Just visit the live demo link above — no setup needed.

---

## 📖 How It Works

1. **Enter** names and marks (0–100) for up to 5 students
2. **Click** the `Analyse →` button
3. **See** instant results:
   - Metric cards update with average, highest, lowest
   - Results table shows each student with a status badge
   - Bar chart renders with color-coded bars

---

## 🎨 Tech Stack

- **HTML5 Canvas** — animated particle background
- **CSS3** — glassmorphism panels, responsive grid
- **Vanilla JavaScript** — all dashboard logic
- **[Chart.js 4.4.1](https://www.chartjs.org/)** — bar chart rendering
- **[Google Fonts](https://fonts.google.com/)** — DM Sans + Space Mono

---

## ⚙️ GitHub Pages Setup

This repo auto-deploys via GitHub Actions. To enable on your fork:

1. Go to your repo → **Settings** → **Pages**
2. Under **Source**, select **GitHub Actions**
3. Push any commit to `main` — it deploys automatically

---

## 📄 License

MIT License — free to use, modify, and distribute.

---

<div align="center">

Made with 💜 · [Report an Issue](https://github.com/YOUR-USERNAME/student-performance-analysis/issues)

</div>
